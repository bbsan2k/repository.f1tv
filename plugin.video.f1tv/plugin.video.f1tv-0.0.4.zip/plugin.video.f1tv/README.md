# This is an (unofficial) F1TV AddOn for Kodi 17 and above

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Disclaimer

This plugin is not officially commisioned/supported by F1TV / FOM.
The trademark "F1TV" is registered by "The Formula 1 Companies"

## Installation & Updates

Please use the release archive for now. Once the AddOn is out of beta stage, I will submit it to a bigger repository.

##Be aware:

- This is really _really_ early beta
- There WILL be bugs


## What's working?

- Watching Content from the archive
- Watching Content (including cockpit views) from this season

## Backlog

- Add Meta data (if available)
- Change Menu Structure to also include "Sets" from F1TV Website
- ...

## Something doesn't work

If something doesn't work for you, please:

- Open an issue with a titles that summarises your problems

## Licence

Licenced under The MIT License.